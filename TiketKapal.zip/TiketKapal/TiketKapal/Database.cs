﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SQLite;
using System.Data;

namespace TiketKapal
{
    internal class Database
    {
        public SQLiteConnection conn;
        private string dbname = "appdb.sqlite3";
        public string query;
        public string value;


        public Database(string query)
        {

            conn = new SQLiteConnection($"Data Source={dbname}");
            if (!File.Exists($"./{dbname}"))
            {
                SQLiteConnection.CreateFile(dbname);
                constructDb();
            }
            this.query = query;
        }
        private void constructDb()
        {
            openConn();
            SQLiteCommand cmd = new SQLiteCommand(conn);
            cmd.CommandText = "BEGIN TRANSACTION; CREATE TABLE IF NOT EXISTS \"ticket_type\" ( \"ticket_type_id\" INTEGER NOT NULL, \"ticket_type_name\" TEXT NOT NULL UNIQUE, PRIMARY KEY(\"ticket_type_id\")); CREATE TABLE IF NOT EXISTS \"destination\"(\"destination_id\" INTEGER NOT NULL, \"destination_port\" TEXT NOT NULL,       \"destination_city\" TEXT NOT NULL, PRIMARY KEY(\"destination_id\")); CREATE TABLE IF NOT EXISTS \"user\"(\"user_id\" INTEGER NOT NULL, \"user_name\" TEXT NOT NULL UNIQUE,    \"user_password\" TEXT NOT NULL UNIQUE, PRIMARY KEY(\"user_id\")); CREATE TABLE IF NOT EXISTS \"ticket\"(\"ticket_id\" TEXT NOT NULL, \"depart_schedule\" TEXT NOT NULL,\"arrival_schedule\" TEXT NOT NULL, \"depart_from\" INTEGER NOT NULL, \"arrive_at\" INTEGER NOT NULL, \"expire_date\" TEXT NOT NULL, \"price\" NUMERIC NOT NULL, \"status\" NUMERIC NOT NULL, \"ticket_type_id_fk\" INTEGER NOT NULL, FOREIGN KEY(\"depart_from\") REFERENCES \"destination\"(\"destination_id\"), FOREIGN KEY(\"arrive_at\") REFERENCES \"destination\"(\"destination_id\"), FOREIGN KEY(\"ticket_type_id_fk\") REFERENCES \"ticket_type\"(\"ticket_type_id\"), PRIMARY KEY(\"ticket_id\")); CREATE TABLE IF NOT EXISTS \"transaction\"(\"transaction_id\" TEXT NOT NULL, \"transaction_date\" TEXT NOT NULL, \"transaction_status\" NUMERIC NOT NULL, \"user_id_fk\" INTEGER NOT NULL,       \"ticket_id_fk\" TEXT NOT NULL, FOREIGN KEY(\"ticket_id_fk\") REFERENCES \"ticket\"(\"ticket_id\"), FOREIGN KEY(\"user_id_fk\") REFERENCES \"user\"(\"user_id\"), PRIMARY KEY(\"transaction_id\")); INSERT INTO \"ticket_type\"(\"ticket_type_id\", \"ticket_type_name\") VALUES(1, 'Reguler'), (2, 'Eksekutif'); INSERT INTO \"destination\"(\"destination_id\", \"destination_port\", \"destination_city\") VALUES(1, 'Tanjung Emas', 'Semarang, Jawa Tengah'), (2, 'Tanjung Perak', 'Surabaya, Jawa Timur'), (3, 'Tanjung Priok', 'Jakarta, DKI Jakarta'), (4, 'Gilimanuk', 'Gilimanuk, Bali'), (5, 'Ketapang', 'Banyuwangi, Jawa Timur'), (6, 'Bakauheni', 'Bakauheni, Lampung'), (7, 'Makassar', 'Makassar, Sulawesi Selatan'), (8, 'Jayapura', 'Jayapura, Papua'), (9, 'Cirebon', 'Cirebon, Jawa Barat'); INSERT INTO \"user\"(\"user_id\", \"user_name\", \"user_password\") VALUES(1, '1', '1'); INSERT INTO \"ticket\"(\"ticket_id\", \"depart_schedule\", \"arrival_schedule\", \"depart_from\", \"arrive_at\", \"expire_date\", \"price\", \"status\", \"ticket_type_id_fk\") VALUES('LS-001', '15-06-2022', '21-06-2022', 1, 7, '22-06-2022', 150000, 1, 2), ('LS-002', '17-06-2022', '17-06-2022', 4, 5, '24-06-2022', 50000, 1, 1), ('LS-003', '20-06-2022', '22-06-2022', 2, 1, '25-06-2022', 200000, 1, 1), ('LS-004', '18-06-2022', '27-06-2022', 9, 8, '04-07-2022', 1000000, 1, 2), ('LS-005', '28-06-2022', '05-07-2022', 3, 5, '07-07-2022', 350000, 1, 1), ('LS-006', '19-06-2022', '24-06-2022', 3, 4, '25-06-2022', 600000, 1, 2), ('LS-007', '21-06-2022', '26-06-2022', 7, 5, '27-06-2022', 400000, 1, 2), ('LS-008', '24-06-2022', '30-06-2022', 6, 4, '01-07-2022', 450000, 1, 1); COMMIT;";            
            cmd.ExecuteNonQuery();
            closeConn();
            cmd.Dispose();
        }
        internal void ExecNonQuery()
        {
            openConn();
            SQLiteCommand cmd = new SQLiteCommand(query, conn);
            cmd.ExecuteNonQuery();
            closeConn();
            cmd.Dispose();
        }
        internal void FetchValue()
        {
            openConn();
            SQLiteCommand cmd = new SQLiteCommand(query, conn);
            SQLiteDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                try
                {
                    value = reader.GetString(0);
                }
                catch (Exception)
                {
                    value = Convert.ToString(reader.GetInt32(0));
                }
            }
            closeConn();
            cmd.Dispose();
        }
        internal void TableReader(DataGridView dgv, DataTable dt)
        {
            openConn();
            SQLiteCommand cmd = new SQLiteCommand(query, conn);
            SQLiteDataReader dr = cmd.ExecuteReader();
            dt.Load(dr);
            dgv.DataSource = dt;
            closeConn();
            cmd.Dispose();
        }
        public void openConn()
        {
            if (conn.State != System.Data.ConnectionState.Open)
            {
                conn.Open();
            }
        }

        public void closeConn()
        {
            if (conn.State != System.Data.ConnectionState.Closed)
            {
                conn.Close();
            }
        }

    }
}
