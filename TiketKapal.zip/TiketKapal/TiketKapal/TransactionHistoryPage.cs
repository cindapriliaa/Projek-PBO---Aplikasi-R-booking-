﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SQLite;

namespace TiketKapal
{
    public partial class TransactionHistoryPage : Form
    {
        public string ticket_id;
        public int tra_user_id;
        public string destination;
        public string tra_date;
        public string tra_id;
        public string combox;
        public TransactionHistoryPage(int tra_user_id)
        {
            InitializeComponent();
            this.tra_user_id = tra_user_id;

            DataGridViewComboBoxColumn comboBoxColumn = new DataGridViewComboBoxColumn();
            comboBoxColumn.Name = "Ubah";
            comboBoxColumn.Width = 100;
            comboBoxColumn.Items.Add("Cetak");
            comboBoxColumn.Items.Add("Batalkan");
            comboBoxColumn.Items.Add("Hapus");
            this.dgv2.Columns.Add(comboBoxColumn);
            Database tra = new Database($"SELECT tra.transaction_id as \"Transaksi ID\", t.ticket_id as \"ID Tiket\", u.user_name as \"Nama\", tra.transaction_date as \"Tgl Transaksi\" FROM \"transaction\" tra JOIN \"ticket\" t ON tra.ticket_id_fk = t.ticket_id JOIN \"user\" u ON tra.user_id_fk = u.user_id and u.user_id = '{tra_user_id}' ORDER BY tra.ticket_id_fk;");
            DataTable dt = new DataTable();
            tra.TableReader(dgv2, dt);
            dgv2.RowHeadersVisible = false;

        }
        private void TransactionHistoryPage_FormClosing(object sender, FormClosingEventArgs e)
        {
            MainPage mp = new MainPage(tra_user_id);
            mp.Show();
            this.Hide();
        }

        private void TransactionHistoryPage_Load(object sender, EventArgs e)
        {

        }

        private void dgv2_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            int selectedrowindex = dgv2.SelectedCells[0].RowIndex;
            DataGridViewRow selectedRow = dgv2.Rows[selectedrowindex];
            this.tra_id = Convert.ToString(selectedRow.Cells[1].Value);
            this.ticket_id = Convert.ToString(selectedRow.Cells[2].Value);
            this.tra_date = Convert.ToString(selectedRow.Cells[4].Value);
            if (e.ColumnIndex == dgv2.Columns["Ubah"].Index)
            {
                bool condition = true;
                if (combox == "Cetak")
                {
                    CallInvoicePage();
                }
                else if (combox == "Batalkan")
                {
                    if (MessageBox.Show("Yakin Ingin Membatalkan?", "Pembatalan", MessageBoxButtons.YesNo, MessageBoxIcon.Question, condition ? MessageBoxDefaultButton.Button2 : MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        Database tra = new Database($"UPDATE \"transaction\" SET transaction_status = 0 WHERE ticket_id_fk = '{ticket_id}';");
                        tra.openConn();
                        tra.ExecNonQuery();
                        MessageBox.Show("Transaksi Berhasil Dibatalkan");
                    }
                    else
                    {
                        MessageBox.Show("Transaksi Tidak Jadi Dibatalkan");
                    }

                }
                else if (combox == "Hapus")
                {
                    if (MessageBox.Show("Yakin Ingin Menghapus?", "Penghapusan", MessageBoxButtons.YesNo, MessageBoxIcon.Question, condition ? MessageBoxDefaultButton.Button2 : MessageBoxDefaultButton.Button1) == DialogResult.Yes)
                    {
                        Database tra = new Database($"DELETE FROM \"transaction\" WHERE ticket_id_fk = '{ticket_id}';");
                        tra.openConn();
                        tra.ExecNonQuery();
                        MessageBox.Show("Transaksi Berhasil Dihapus");
                    }
                    else
                    {
                        MessageBox.Show("Transaksi Tidak Jadi Dihapus");
                    }
                }
            }
            ShowAllMethod();
        }
        private void CallInvoicePage()
        {
            Database user_name = new Database($"SELECT user_name FROM user WHERE user_id = {tra_user_id};");
            Database dest = new Database($"SELECT d1.destination_port ||', '|| d1.destination_city ||' - '|| d2.destination_port ||', '|| d2.destination_city FROM \"transaction\" tra JOIN ticket t ON tra.ticket_id_fk = t.ticket_id LEFT JOIN destination d1 ON d1.destination_id = t.depart_from LEFT JOIN destination d2 ON d2.destination_id = t.arrive_at WHERE tra.ticket_id_fk = '{ticket_id}';");
            Database price = new Database($"SELECT t.price FROM \"transaction\" tra JOIN ticket t ON tra.ticket_id_fk = t.ticket_id LEFT JOIN destination d1 ON d1.destination_id = t.depart_from LEFT JOIN destination d2 ON d2.destination_id = t.arrive_at WHERE tra.ticket_id_fk = '{ticket_id}';");
            price.FetchValue();
            user_name.FetchValue();
            dest.openConn();
            SQLiteCommand cmd = new SQLiteCommand(dest.query, dest.conn);
            SQLiteDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                this.destination = reader.GetString(0);
            }
            InvoicePage ip = new InvoicePage(tra_id, tra_date, user_name.value, Convert.ToInt32(tra_user_id), ticket_id, Convert.ToInt32(price.value), destination);
            ip.Show();
            this.Hide();
        }
        private void dgv2_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            var combo = e.Control as ComboBox;
            if (combo != null)
            {
                combo.SelectedIndexChanged -= new EventHandler(combo_SelectedIndexChanged);
                combo.SelectedIndexChanged += combo_SelectedIndexChanged;
            }
        }
        private void combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            this.combox = (sender as ComboBox).SelectedItem.ToString();
        }
        private void ShowAllMethod()
        {
            Database tra = new Database($"SELECT tra.transaction_id as \"Transaksi ID\", t.ticket_id as \"ID Tiket\", u.user_name as \"Nama\", tra.transaction_date as \"Tgl Transaksi\" FROM \"transaction\" tra JOIN \"ticket\" t ON tra.ticket_id_fk = t.ticket_id JOIN \"user\" u ON tra.user_id_fk = u.user_id and u.user_id = '{tra_user_id}' ORDER BY tra.ticket_id_fk;");
            DataTable dt = new DataTable();
            tra.TableReader(dgv2, dt);
            dgv2.RowHeadersVisible = false;
        }

        private void dgv2_CellFormatting(object sender, DataGridViewCellFormattingEventArgs e)
        {
            foreach (DataGridViewRow row in dgv2.Rows)
            {
                Database status = new Database($"SELECT transaction_status FROM \"transaction\" WHERE ticket_id_fk = '{row.Cells[2].Value}';");
                status.FetchValue();
                int statusvalue = Convert.ToInt32(status.value);
                if (statusvalue == 0)
                {
                    row.DefaultCellStyle.BackColor = Color.Pink;
                }
                else if (statusvalue == 1)
                {
                    row.DefaultCellStyle.BackColor = Color.LightGreen;
                }
            }
        }
    }
}
